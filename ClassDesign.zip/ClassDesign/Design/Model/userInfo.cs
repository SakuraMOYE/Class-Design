﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model//实体类库
{
    public class userInfo//登录类
    {
        public string UserName { get; set; }
        public string PassWords { get; set; }
    }
}
