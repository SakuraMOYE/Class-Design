﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Design
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 0;
        }

        string select="用户入口";
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {//用combox的选择对select进行赋值
            select = comboBox1.SelectedItem.ToString();
        }
        private void button2_Click(object sender, EventArgs e)
        {//将enrollment窗体展示在前台，并不允许对login进行编辑
            new enrollment().ShowDialog();
        }

        private void login_FormClosing(object sender, FormClosingEventArgs e)
        {//退出时二次确认窗口
            if (DialogResult.Cancel == MessageBox.Show("确认退出吗？", "提示", MessageBoxButtons.OKCancel))
            {
                e.Cancel = true;
            }
        }

        Model.userInfo user = new Model.userInfo();//实例化userInfo实体类
        BLL.loginManage mgr = new BLL.loginManage();//实体化业务逻辑层的loginManage类
        private void button1_Click(object sender, EventArgs e)
        {
            //通过user对象将用户输入的账户和密码传递给userInfo的userName和passWord
            user.UserName = username.Text.Trim();
            user.PassWords = password.Text.Trim();
            switch (select)//根据select的值选择登录权限
            {
                case ("用户入口"):
                    //UI层将用户输入数据传递给BLL层，将UI层返回业务层传递的数据给用户
                    //如果BLL层中userLogin调用返回记录条数大于1则账号密码正确
                    if (mgr.userLogin(user) > 0)
                    {
                        DialogResult dr = MessageBox.Show("登录成功", "提示");
                        if (dr == DialogResult.OK)
                        {
                            new UserOrder(username.Text).Show();//打开点餐窗口
                        }
                    }
                    else
                    {
                        MessageBox.Show("登录失败");//用户名或密码错误
                    }
                    break;
                case ("骑手入口"):
                    if (mgr.riderLogin(user) > 0)
                    {
                        DialogResult dr = MessageBox.Show("登录成功", "233");
                        if (dr == DialogResult.OK)
                        {
                            new Take(username.Text).Show();//打开接单大厅
                        }
                    }
                    else
                    {
                        MessageBox.Show("登录失败");//用户名或密码错误
                    }
                    break;
                case ("管理入口"):
                    if (mgr.manageLogin(user) > 0)
                    {
                        DialogResult dr = MessageBox.Show("登录成功", "233");
                        if (dr == DialogResult.OK)
                        {
                            new Manage().Show();//打开菜单的管理界面
                        }
                    }
                    else
                    {
                        MessageBox.Show("登录失败");//用户名或密码错误
                    }
                    break;
            }
        }
    }
}
