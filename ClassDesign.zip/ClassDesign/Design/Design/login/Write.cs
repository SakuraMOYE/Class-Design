﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Design
{
    class Write
    {
        Model.enrollInfo user = new Model.enrollInfo();//实例化userInfo实体类
        BLL.enrollManage mgr = new BLL.enrollManage();//实体化业务逻辑层的loginManage类

        
        public Write (string phoneNum,string passWord,string name)
        {//将用户输入传给user
            user.phoneNum  = phoneNum;
            user.passWords = passWord;
            user.Name = name;
        }

        public void userenrollWrite()//用户写入
        {//执行写入程序
            mgr.userEnrollWrite(user);
        }
        public void riderenrollWrite()//骑手写入
        {
            mgr.riderEnrollWrite(user);
        }
    }
}
