﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Design
{

    class Judge
    {
        Model.enrollInfo user = new Model.enrollInfo();//实例化userInfo实体类
        BLL.enrollManage mgr = new BLL.enrollManage();//实体化业务逻辑层的loginManage类
        
        public Judge (string phoneNum,string name)//构造函数，将输入的值传递给user
        {//将用户输入传递给user
            user.phoneNum = phoneNum;
            user.Name = name;
        }
        bool a;
        public bool usernameconflict()
        {
            if(mgr.userEnrollJudge(user)>0)
            {//如果mgr查询结果大于0，返回true
                a = true;
            }
            else
            {
                a = false;
            }
            return a;
        }
        public bool ridernameconflict()
        {
            if (mgr.riderEnrollJudge(user) > 0)
            {//如果mgr查询结果大于0，返回true
                a = true;
            }
            else
            {
                a = false;
            }
            return a;
        }
    }
}
