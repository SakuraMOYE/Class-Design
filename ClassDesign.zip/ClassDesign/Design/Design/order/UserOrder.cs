﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Design
{
    public partial class UserOrder : Form
    {
        private static string na;//静态设置一个用来存储在登陆界面传递过来的phonenum
        private static string ConStr = "Data Source=.;Initial Catalog=CanteenManage;Integrated Security=True";
        //连接字符串
        public UserOrder(string a)
        {
            InitializeComponent();
            na = a;//将登陆界面的值赋值给静态变量
            label4.Text = a+"，你好！";
            history();//执行历史订单代码
        }
        public void history()
        {
            string CommandText = "select * from dingdan where userphone = '" + na + "'";
            //在数据库通过userphone搜索订单数据表
            SqlConnection conn = new SqlConnection(ConStr);
            //创建数据库连接
            try
            {
                conn.Open();//打开数据库
                SqlDataAdapter Adapter = new SqlDataAdapter(CommandText, conn);
                //实例化SqlDataAdapter对象来执行sql命令
                DataSet ds = new DataSet();
                //实例化dataset
                Adapter.Fill(ds, "dingdan");
                //执行sql命令并将返回的数据表的数据填充到dataset中并命名dingdan
                historyorde.DataSource = ds;//设置datagrideview的datasource
                historyorde.DataMember = "dingdan";//设置datagrideview要显示的表名
            }
            catch(SqlException err)
            {
                MessageBox.Show(err.ToString());
            }
            finally
            {
                conn.Close();//关闭数据库连接
            }
        }
        private void UserOrder_Load(object sender, EventArgs e)
        {
            string CommandText = "select * from Dish";
            //声明字符串变量存储sql查询语句
            SqlConnection conn = new SqlConnection(ConStr);
            try
            {
                conn.Open();
                SqlDataAdapter Adapter = new SqlDataAdapter(CommandText, conn);
                //实例化SqlDataAdapter对象来执行sql命令
                DataSet ds = new DataSet();//实例化dataset
                Adapter.Fill(ds, "Dish");
                Dishlist.DataSource = ds.Tables["Dish"];//设置dishlist的datasource
                Dishlist.ValueMember = "ID";//设置dishlist的valuemember
                Dishlist.DisplayMember = "name";//设置dishlist的displaymember
                Pricelist.DataSource = ds.Tables["Dish"];
                Pricelist.ValueMember = "ID";
                Pricelist.DisplayMember = "price";
            }
            catch (SqlException err)
            {
                MessageBox.Show(err.ToString());
            }
            finally
            {
                conn.Close();//关闭数据库连接
            }
        }

        ArrayList list = new ArrayList();
        //实例化一个arraylist用来存储被勾选的选项
        private void button1_Click(object sender, EventArgs e)
        {
            list.Clear();
            for(int i=0;i<Dishlist.Items.Count;i++)
            {
                if(Dishlist.GetItemChecked (i)==true)
                {
                    list.Add(Dishlist.GetItemText(Dishlist.Items[i]));
                    //将被勾选的选项存储到list内
                }
            }
            ClassOrder co = new ClassOrder(list,na);//实例化classorder并传递list
            allpay.Text = co.AllPay().ToString ();//将计算的总价赋值给allpay
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ClassOrder co = new ClassOrder(list, na);
            if (co.Judge() == true)
            {
                co.Xiadan();
                MessageBox.Show("订单生成成功！！！");
            }
            else
            {
                MessageBox.Show("请先更改收货地址");
            }
        }

        private void button3_Click(object sender, EventArgs e)
            //修改地址button
        {
            string CommandText = "update userInfo set adress='" + comboBox1.SelectedItem + " " + textBox1.Text + "' where ID='" + na + "'";
            //更新数据库字符串
            SqlConnection conn = new SqlConnection(ConStr);
            //创建数据库连接
            SqlCommand cmd = new SqlCommand(CommandText, conn);
            //执行数据库语句
            try
            {
                conn.Open();
                if(cmd.ExecuteNonQuery()>0)
                    //返回受影响行数，若大于0则代表修改成功
                {
                    MessageBox.Show("地址修改成功！");
                }
                else
                {
                    MessageBox.Show("未知错误，请重试！");
                }
            }
            catch(SqlException err)
            {
                MessageBox.Show(err.ToString());
            }
            finally
            {
                conn.Close();//关闭数据库连接
            }
        }
    }
}
