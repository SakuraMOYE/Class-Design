﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Design
{
   class ClassOrder
    {
        private static string ConnStr = "Data Source=.;Initial Catalog=CanteenManage;Integrated Security=True";
        //数据库连接字符串
        ArrayList ar = new ArrayList();//声明arraylist类型ar用来接收被勾选的值
        private static string name;
        public ClassOrder(ArrayList arr,string na)
        {
            ar = arr;
            name = na;
        }
        
        public double AllPay()//计算代码
        {
            double sum = 0;
            foreach (var a in ar)//遍历ar
            {
                string CommandText = "select price from Dish where name= '" + a+"'";
                //sql查询语句
                //通过名字在Dish表中查询价格
                SqlConnection conn = new SqlConnection(ConnStr);//连接数据库
                SqlCommand cmd = new SqlCommand(CommandText, conn);
                //查询数据库
                try
                {
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    //用SqlDataReader将查询到的结果返回给reader
                    while(reader.Read())
                    {
                        sum+= double.Parse(reader[0].ToString ());
                        //将查询到的价格转换为double类型
                        //对遍历的结果进行求和
                    }
                }
                finally
                {
                    conn.Close();//关闭数据库连接
                }
            }
            return sum;
        }

        public bool Judge()
        {
            string CommandText = "select adress from userInfo where ID='"+name+"'";
            SqlConnection conn = new SqlConnection(ConnStr);
            SqlCommand cmd = new SqlCommand(CommandText, conn);
            try
            {
                conn.Open();
                IDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    if (reader[0].ToString().Trim() == "1")
                    { return false; }
                    else
                    { return true; }
                }
            }
            catch
            {
                return false;
            }
            finally
            {
                conn.Close();
            }
            return false;
        }

        public void Xiadan()//确认订单执行代码
        {
            string items=string.Empty;//定义一个字符串用来接收点的菜的内容
            foreach(var a in ar)//遍历ar，将内容用空格分开写入items
            {
                items = items + " " + a;
            }

            SqlConnection conn = new SqlConnection(ConnStr);
            double allpay = AllPay();
            string CommandTextuser = "select Name,adress from userInfo where ID='" + name + "'";
            SqlCommand cmduser = new SqlCommand(CommandTextuser, conn);
            string sename = string.Empty;
            string adress = string.Empty;
            try
            {
                conn.Open();
                SqlDataReader reader = cmduser.ExecuteReader();
                while(reader.Read())
                {
                    sename = reader[0].ToString();
                    adress = reader[1].ToString();
                }
            }
            finally
            {
                conn.Close();
            }
            int num = Bianhao();
            string CommandTextWrite="insert into dingdan (Num,commodity,prices,adress,userphone,username) values("+ num+",\'"+items+"\',"+allpay+",\'"+adress+"\',"+name+",\'"+sename+"\')";
            //写入数据库字符串
            SqlCommand cmd = new SqlCommand(CommandTextWrite, conn);
            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
            }
            finally
            {
                conn.Close();
            }
        }
        public int Bianhao ()
        {
            string CommandTextNum = "select * from dingdan";
            SqlConnection conn = new SqlConnection(ConnStr);
            try
            {
                SqlDataAdapter da = new SqlDataAdapter(CommandTextNum, conn);
                DataSet ds = new DataSet();
                da.Fill(ds);//将查询到的结果写入虚拟表ds
                return ds.Tables[0].Rows.Count + 1;
                //ds表的行数就是数据库类有的数据的条数
                //返回条数加一即为新的订单编号
            }
            finally
            {
                conn.Close();//关闭数据库连接
            }
        }
    }
}
