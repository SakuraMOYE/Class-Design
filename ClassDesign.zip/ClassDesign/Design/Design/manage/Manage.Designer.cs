﻿namespace Design
{
    partial class Manage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Manage));
            this.RB_Add = new System.Windows.Forms.RadioButton();
            this.RB_update = new System.Windows.Forms.RadioButton();
            this.RB_Delete = new System.Windows.Forms.RadioButton();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dishBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.canteenManageDataSet = new Design.CanteenManageDataSet();
            this.dishTableAdapter = new Design.CanteenManageDataSetTableAdapters.DishTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.IDnum = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Dishname = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.price = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dishBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.canteenManageDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // RB_Add
            // 
            this.RB_Add.AutoSize = true;
            this.RB_Add.Font = new System.Drawing.Font("宋体", 24F);
            this.RB_Add.Location = new System.Drawing.Point(12, 54);
            this.RB_Add.Name = "RB_Add";
            this.RB_Add.Size = new System.Drawing.Size(97, 37);
            this.RB_Add.TabIndex = 0;
            this.RB_Add.TabStop = true;
            this.RB_Add.Text = "增加";
            this.RB_Add.UseVisualStyleBackColor = true;
            this.RB_Add.CheckedChanged += new System.EventHandler(this.RB_Add_CheckedChanged);
            // 
            // RB_update
            // 
            this.RB_update.AutoSize = true;
            this.RB_update.Font = new System.Drawing.Font("宋体", 24F);
            this.RB_update.Location = new System.Drawing.Point(12, 141);
            this.RB_update.Name = "RB_update";
            this.RB_update.Size = new System.Drawing.Size(97, 37);
            this.RB_update.TabIndex = 1;
            this.RB_update.TabStop = true;
            this.RB_update.Text = "修改";
            this.RB_update.UseVisualStyleBackColor = true;
            this.RB_update.CheckedChanged += new System.EventHandler(this.RB_update_CheckedChanged);
            // 
            // RB_Delete
            // 
            this.RB_Delete.AutoSize = true;
            this.RB_Delete.Font = new System.Drawing.Font("宋体", 24F);
            this.RB_Delete.Location = new System.Drawing.Point(12, 249);
            this.RB_Delete.Name = "RB_Delete";
            this.RB_Delete.Size = new System.Drawing.Size(97, 37);
            this.RB_Delete.TabIndex = 2;
            this.RB_Delete.TabStop = true;
            this.RB_Delete.Text = "删除";
            this.RB_Delete.UseVisualStyleBackColor = true;
            this.RB_Delete.CheckedChanged += new System.EventHandler(this.RB_Delete_CheckedChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.dishBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(509, 54);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(648, 263);
            this.dataGridView1.TabIndex = 3;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.ReadOnly = true;
            this.iDDataGridViewTextBoxColumn.Width = 200;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            this.nameDataGridViewTextBoxColumn.Width = 200;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "price";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.ReadOnly = true;
            this.priceDataGridViewTextBoxColumn.Width = 200;
            // 
            // dishBindingSource
            // 
            this.dishBindingSource.DataMember = "Dish";
            this.dishBindingSource.DataSource = this.canteenManageDataSet;
            // 
            // canteenManageDataSet
            // 
            this.canteenManageDataSet.DataSetName = "CanteenManageDataSet";
            this.canteenManageDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dishTableAdapter
            // 
            this.dishTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Yellow;
            this.button1.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Bold);
            this.button1.Location = new System.Drawing.Point(572, 333);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(571, 83);
            this.button1.TabIndex = 4;
            this.button1.Text = "刷新";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Yellow;
            this.button2.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Bold);
            this.button2.Location = new System.Drawing.Point(39, 333);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(507, 83);
            this.button2.TabIndex = 5;
            this.button2.Text = "确定";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(404, 27);
            this.label1.TabIndex = 6;
            this.label1.Text = "每次修改完成请点击刷新！！！";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 20F);
            this.label2.Location = new System.Drawing.Point(132, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 27);
            this.label2.TabIndex = 7;
            this.label2.Text = "ID：";
            // 
            // IDnum
            // 
            this.IDnum.Font = new System.Drawing.Font("宋体", 20F);
            this.IDnum.Location = new System.Drawing.Point(292, 64);
            this.IDnum.Name = "IDnum";
            this.IDnum.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.IDnum.Size = new System.Drawing.Size(211, 38);
            this.IDnum.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 20F);
            this.label3.Location = new System.Drawing.Point(132, 150);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 27);
            this.label3.TabIndex = 7;
            this.label3.Text = "菜名：";
            // 
            // Dishname
            // 
            this.Dishname.Font = new System.Drawing.Font("宋体", 20F);
            this.Dishname.Location = new System.Drawing.Point(292, 139);
            this.Dishname.Name = "Dishname";
            this.Dishname.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Dishname.Size = new System.Drawing.Size(211, 38);
            this.Dishname.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 20F);
            this.label4.Location = new System.Drawing.Point(132, 215);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 27);
            this.label4.TabIndex = 7;
            this.label4.Text = "价格：";
            // 
            // price
            // 
            this.price.Font = new System.Drawing.Font("宋体", 20F);
            this.price.Location = new System.Drawing.Point(292, 204);
            this.price.Name = "price";
            this.price.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.price.Size = new System.Drawing.Size(211, 38);
            this.price.TabIndex = 8;
            // 
            // Manage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1169, 450);
            this.Controls.Add(this.price);
            this.Controls.Add(this.Dishname);
            this.Controls.Add(this.IDnum);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.RB_Delete);
            this.Controls.Add(this.RB_update);
            this.Controls.Add(this.RB_Add);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Manage";
            this.Text = "管理";
            this.Load += new System.EventHandler(this.Manage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dishBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.canteenManageDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton RB_Add;
        private System.Windows.Forms.RadioButton RB_update;
        private System.Windows.Forms.RadioButton RB_Delete;
        private System.Windows.Forms.DataGridView dataGridView1;
        private CanteenManageDataSet canteenManageDataSet;
        private System.Windows.Forms.BindingSource dishBindingSource;
        private CanteenManageDataSetTableAdapters.DishTableAdapter dishTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox IDnum;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Dishname;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox price;
    }
}