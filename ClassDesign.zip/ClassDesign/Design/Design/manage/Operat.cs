﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Design
{
    class Operat//基类
    {
        public virtual void Modify()//虚方法
        { }
    }
    class Judgemanage//判断类
    {
        Model.manage mma = new Model.manage();//实例化manage实体类
        BLL.manage bma = new BLL.manage();//实体化业务逻辑层的manage类

        public Judgemanage(string ID, string name)//构造函数，将输入的值传递给manage
        {//将用户输入传递给Model的mma
            mma.ID = ID;
            mma.name = name;
        }
        bool a;
        public bool judgeidname()//若查找有返回值，方法为true
        {
            if (bma.dishSearch(mma) > 0)
            {//如果BLL的bma查询结果大于0，返回true
                a = true;
            }
            else
            {
                a = false;
            }
            return a;
        }
    }
    class Add : Operat//添加类继承基类
    {
        Model.manage mma = new Model.manage();//实例化manage实体类
        BLL.manage bma = new BLL.manage();//实体化业务逻辑层的manage类

        public Add(string ID,string name,string price)//构造函数，传递输入的数值
        {
            mma.ID = ID;
            mma.name = name;
            mma.price = price;
        }
        public override void Modify()//重写基类虚方法
        {
            bma.dishAdd(mma);
        }
    }
    class Update:Operat//更新类继承基类
    {
        Model.manage mma = new Model.manage();//实例化manage实体类
        BLL.manage bma = new BLL.manage();//实体化业务逻辑层的manage类

        public Update(string ID, string name, string price)//构造函数，传递输入的数值
        {
            mma.ID = ID;
            mma.name = name;
            mma.price = price;
        }
        public override void Modify()//重写基类虚方法
        {
            bma.dishUpdate(mma);
        }
    }
    class Delete : Operat//删除类继承基类
    {
        Model.manage mma = new Model.manage();//实例化manage实体类
        BLL.manage bma = new BLL.manage();//实体化业务逻辑层的manage类

        public Delete(string ID, string name, string price)//构造函数，传递输入的数值
        {
            mma.ID = ID;
            mma.name = name;
            mma.price = price;
        }
        public override void Modify()//重写基类虚方法
        {
            bma.dishDelete(mma);
        }
    }
}
