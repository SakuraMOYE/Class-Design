﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Design
{
    public partial class Manage : Form
    {
        public Manage()
        {
            InitializeComponent();
        }

        private void Manage_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“canteenManageDataSet.Dish”中。您可以根据需要移动或删除它。
            this.dishTableAdapter.Fill(this.canteenManageDataSet.Dish);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            new Manage().Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Judgemanage jm = new Judgemanage(IDnum.Text.Trim(), Dishname.Text.Trim());
            switch (a)
            {
                case (1):
                    if (IDnum.Text.Trim() == "" || Dishname.Text.Trim() == "" || price.Text.Trim() == "")
                    {
                        MessageBox.Show("ID和菜名不能为空！");
                    }
                    else if (jm.judgeidname() == true)
                    {
                        MessageBox.Show("该ID或该菜名已被记录，请重新输入！", "提示：");
                    }
                    else
                    {
                        Operat op = new Add(IDnum.Text.Trim(), Dishname.Text.Trim(), price.Text.Trim());
                        op.Modify();
                        if (MessageBox.Show("添加数据成功，是否继续修改数据？", "提示：", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                        {
                            this.Close();
                        }
                    }
                    break;
                case (2):
                    if (jm.judgeidname() == true)
                    {
                        Operat op = new Delete(IDnum.Text.Trim(), Dishname.Text.Trim(), price.Text.Trim());
                        op.Modify();
                        if (MessageBox.Show("删除数据成功，是否继续修改数据？", "提示：", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                        {
                            this.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("未查询到该ID或名字对应的菜名！", "提示：");
                    }
                    break;
                case (3):
                    if (jm.judgeidname() == true)
                    {
                        Operat op = new Update(IDnum.Text.Trim(), Dishname.Text.Trim(), price.Text.Trim());
                        op.Modify();
                        if (MessageBox.Show("更新数据成功，是否继续修改数据？", "提示：", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                        {
                            this.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("未查询到该ID或名字对应的菜名！", "提示：");
                    }
                    break;
            }
        }
        int a = 1;
        private void RB_Add_CheckedChanged(object sender, EventArgs e)
        {
            label4.Text = "价格：";
            a = 1;

        }

        private void RB_update_CheckedChanged(object sender, EventArgs e)
        {
            label4.Text = "价格更改为：";
            a = 3;
        }

        private void RB_Delete_CheckedChanged(object sender, EventArgs e)
        {
            label4.Text = "价格";
            a = 2;
        }
    }
}
