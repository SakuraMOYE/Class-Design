﻿namespace Design
{
    partial class Take
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Take));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.refresh1 = new System.Windows.Forms.Button();
            this.userphonelist1 = new System.Windows.Forms.ListBox();
            this.usernamelist1 = new System.Windows.Forms.ListBox();
            this.adresslist1 = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.CLB_weijie = new System.Windows.Forms.CheckedListBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.userphonelist2 = new System.Windows.Forms.ListBox();
            this.usernamelist2 = new System.Windows.Forms.ListBox();
            this.adresslist2 = new System.Windows.Forms.ListBox();
            this.refresh2 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.CLB_yijie = new System.Windows.Forms.CheckedListBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.historyOrder = new System.Windows.Forms.DataGridView();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.historyOrder)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Bold);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1156, 450);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tabPage1.Controls.Add(this.refresh1);
            this.tabPage1.Controls.Add(this.userphonelist1);
            this.tabPage1.Controls.Add(this.usernamelist1);
            this.tabPage1.Controls.Add(this.adresslist1);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.CLB_weijie);
            this.tabPage1.Location = new System.Drawing.Point(4, 37);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1148, 409);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "抢单大厅";
            // 
            // refresh1
            // 
            this.refresh1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.refresh1.Location = new System.Drawing.Point(867, 246);
            this.refresh1.Name = "refresh1";
            this.refresh1.Size = new System.Drawing.Size(205, 133);
            this.refresh1.TabIndex = 5;
            this.refresh1.Text = "刷新界面";
            this.refresh1.UseVisualStyleBackColor = false;
            this.refresh1.Click += new System.EventHandler(this.refresh1_Click);
            // 
            // userphonelist1
            // 
            this.userphonelist1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.userphonelist1.Font = new System.Drawing.Font("宋体", 24F, System.Drawing.FontStyle.Bold);
            this.userphonelist1.FormattingEnabled = true;
            this.userphonelist1.ItemHeight = 33;
            this.userphonelist1.Location = new System.Drawing.Point(529, 3);
            this.userphonelist1.Name = "userphonelist1";
            this.userphonelist1.Size = new System.Drawing.Size(186, 400);
            this.userphonelist1.TabIndex = 4;
            // 
            // usernamelist1
            // 
            this.usernamelist1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.usernamelist1.Font = new System.Drawing.Font("宋体", 24F, System.Drawing.FontStyle.Bold);
            this.usernamelist1.FormattingEnabled = true;
            this.usernamelist1.ItemHeight = 33;
            this.usernamelist1.Location = new System.Drawing.Point(412, 3);
            this.usernamelist1.Name = "usernamelist1";
            this.usernamelist1.Size = new System.Drawing.Size(120, 400);
            this.usernamelist1.TabIndex = 3;
            // 
            // adresslist1
            // 
            this.adresslist1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.adresslist1.Font = new System.Drawing.Font("宋体", 24F, System.Drawing.FontStyle.Bold);
            this.adresslist1.FormattingEnabled = true;
            this.adresslist1.ItemHeight = 33;
            this.adresslist1.Location = new System.Drawing.Point(95, 3);
            this.adresslist1.Name = "adresslist1";
            this.adresslist1.Size = new System.Drawing.Size(321, 400);
            this.adresslist1.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Location = new System.Drawing.Point(867, 53);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(206, 137);
            this.button1.TabIndex = 1;
            this.button1.Text = "确认接单";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // CLB_weijie
            // 
            this.CLB_weijie.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.CLB_weijie.CheckOnClick = true;
            this.CLB_weijie.FormattingEnabled = true;
            this.CLB_weijie.Location = new System.Drawing.Point(3, 3);
            this.CLB_weijie.Name = "CLB_weijie";
            this.CLB_weijie.Size = new System.Drawing.Size(95, 400);
            this.CLB_weijie.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tabPage2.Controls.Add(this.userphonelist2);
            this.tabPage2.Controls.Add(this.usernamelist2);
            this.tabPage2.Controls.Add(this.adresslist2);
            this.tabPage2.Controls.Add(this.refresh2);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.CLB_yijie);
            this.tabPage2.Location = new System.Drawing.Point(4, 37);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1148, 407);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "已接取订单";
            // 
            // userphonelist2
            // 
            this.userphonelist2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.userphonelist2.Font = new System.Drawing.Font("宋体", 24F, System.Drawing.FontStyle.Bold);
            this.userphonelist2.FormattingEnabled = true;
            this.userphonelist2.ItemHeight = 33;
            this.userphonelist2.Location = new System.Drawing.Point(556, 3);
            this.userphonelist2.Name = "userphonelist2";
            this.userphonelist2.Size = new System.Drawing.Size(186, 400);
            this.userphonelist2.TabIndex = 7;
            // 
            // usernamelist2
            // 
            this.usernamelist2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.usernamelist2.Font = new System.Drawing.Font("宋体", 24F, System.Drawing.FontStyle.Bold);
            this.usernamelist2.FormattingEnabled = true;
            this.usernamelist2.ItemHeight = 33;
            this.usernamelist2.Location = new System.Drawing.Point(439, 3);
            this.usernamelist2.Name = "usernamelist2";
            this.usernamelist2.Size = new System.Drawing.Size(120, 400);
            this.usernamelist2.TabIndex = 6;
            // 
            // adresslist2
            // 
            this.adresslist2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.adresslist2.Font = new System.Drawing.Font("宋体", 24F, System.Drawing.FontStyle.Bold);
            this.adresslist2.FormattingEnabled = true;
            this.adresslist2.ItemHeight = 33;
            this.adresslist2.Location = new System.Drawing.Point(122, 3);
            this.adresslist2.Name = "adresslist2";
            this.adresslist2.Size = new System.Drawing.Size(321, 400);
            this.adresslist2.TabIndex = 5;
            // 
            // refresh2
            // 
            this.refresh2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.refresh2.Location = new System.Drawing.Point(873, 222);
            this.refresh2.Name = "refresh2";
            this.refresh2.Size = new System.Drawing.Size(224, 147);
            this.refresh2.TabIndex = 1;
            this.refresh2.Text = "刷新界面";
            this.refresh2.UseVisualStyleBackColor = false;
            this.refresh2.Click += new System.EventHandler(this.refresh2_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button2.Location = new System.Drawing.Point(873, 33);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(224, 147);
            this.button2.TabIndex = 1;
            this.button2.Text = "完成订单";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // CLB_yijie
            // 
            this.CLB_yijie.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.CLB_yijie.CheckOnClick = true;
            this.CLB_yijie.FormattingEnabled = true;
            this.CLB_yijie.Location = new System.Drawing.Point(3, 3);
            this.CLB_yijie.Name = "CLB_yijie";
            this.CLB_yijie.Size = new System.Drawing.Size(123, 400);
            this.CLB_yijie.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.historyOrder);
            this.tabPage3.Location = new System.Drawing.Point(4, 37);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1148, 407);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "已完成订单";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // historyOrder
            // 
            this.historyOrder.AllowUserToAddRows = false;
            this.historyOrder.AllowUserToDeleteRows = false;
            this.historyOrder.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.historyOrder.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.historyOrder.Location = new System.Drawing.Point(3, 4);
            this.historyOrder.Name = "historyOrder";
            this.historyOrder.ReadOnly = true;
            this.historyOrder.RowTemplate.Height = 23;
            this.historyOrder.Size = new System.Drawing.Size(1142, 402);
            this.historyOrder.TabIndex = 0;
            // 
            // Take
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aqua;
            this.ClientSize = new System.Drawing.Size(1155, 450);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Take";
            this.Text = "骑手界面";
            this.Load += new System.EventHandler(this.Take_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.historyOrder)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckedListBox CLB_weijie;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.CheckedListBox CLB_yijie;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView historyOrder;
        private System.Windows.Forms.ListBox userphonelist1;
        private System.Windows.Forms.ListBox usernamelist1;
        private System.Windows.Forms.ListBox adresslist1;
        private System.Windows.Forms.ListBox userphonelist2;
        private System.Windows.Forms.ListBox usernamelist2;
        private System.Windows.Forms.ListBox adresslist2;
        private System.Windows.Forms.Button refresh2;
        private System.Windows.Forms.Button refresh1;
    }
}