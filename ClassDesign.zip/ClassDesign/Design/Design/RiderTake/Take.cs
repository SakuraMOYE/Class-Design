﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Design
{
    public partial class Take : Form
    {
        private static string ConStr = "Data Source=.;Initial Catalog=CanteenManage;Integrated Security=True";
        //连接字符串
        string name=string.Empty;//存储登录时的Riderphone
        public Take(string na)
        {
            InitializeComponent();
            name = na;
        }

        private void Take_Load(object sender, EventArgs e)
        {
            string CommandTextHistory = "select * from dingdan where Riderphone='" + name + "' and Status='已完成'";
            //历史订单，索引为已完成Riderphone为自己
            string CommandTextNo = "select * from dingdan where Status='未接单'";
            //所有未接单的订单
            string CommandTextYes = "select * from dingdan where Status='已接单' and Riderphone='" + name + "'";
            //自己接的单
            SqlConnection conn = new SqlConnection(ConStr);
            try
            {
                conn.Open();
                SqlDataAdapter AdapterHistory = new SqlDataAdapter(CommandTextHistory, conn);
                //历史订单数据库连接
                SqlDataAdapter AdapterNo = new SqlDataAdapter(CommandTextNo, conn);
                //未接单数据库连接
                SqlDataAdapter AdapterYes = new SqlDataAdapter(CommandTextYes, conn);
                //已结单数据库连接
                DataSet ds = new DataSet();//实例化Dataset
                AdapterNo.Fill(ds, "Weijie");//创建索引为未接单的虚拟表
                CLB_weijie.DataSource = ds.Tables["Weijie"];//ckeckedlistbox写入Num的值
                CLB_weijie.ValueMember = "Num";
                CLB_weijie.DisplayMember = "Num";

                adresslist1.DataSource = ds.Tables["Weijie"];//地址listbox写入地址
                adresslist1.ValueMember = "Num";
                adresslist1.DisplayMember = "adress";

                usernamelist1.DataSource = ds.Tables["Weijie"];//用户名listbox写入用户名
                usernamelist1.ValueMember = "Num";
                usernamelist1.DisplayMember = "username";

                userphonelist1.DataSource = ds.Tables["Weijie"];//用户手机号listbox写入手机号
                userphonelist1.ValueMember = "Num";
                userphonelist1.DisplayMember = "userphone";

                AdapterYes.Fill(ds, "Yijie");//创建索引为已接单并且Riderphone是自己的虚拟表
                CLB_yijie.DataSource = ds.Tables["Yijie"];
                CLB_yijie.ValueMember = "Num";//checkedlistbox写入Num值
                CLB_yijie.DisplayMember = "Num";

                adresslist2.DataSource = ds.Tables["Yijie"];//地址listbox写入地址
                adresslist2.ValueMember = "Num";
                adresslist2.DisplayMember = "adress";

                usernamelist2.DataSource = ds.Tables["Yijie"];//用户名listbox写入用户姓名
                usernamelist2.ValueMember = "Num";
                usernamelist2.DisplayMember = "username";

                userphonelist2.DataSource = ds.Tables["Yijie"];//用户手机号listbox写入用户手机号
                userphonelist2.ValueMember = "Num";
                userphonelist2.DisplayMember = "userphone";

                AdapterHistory.Fill(ds, "dingdan");//在历史订单写入索引为已完成并且Riderphone是自己的所有订单
                historyOrder.DataSource = ds;
                historyOrder.DataMember = "dingdan";
            }
            finally
            {
                conn.Close();
            }
        }
        ArrayList list = new ArrayList();
        private void button1_Click(object sender, EventArgs e)
        {
            list.Clear();
            for (int i = 0; i < CLB_weijie.Items.Count; i++)
            {//遍历CLB_weijie，将被勾选的选项存入list
                if (CLB_weijie.GetItemChecked(i))
                {
                    list.Add(CLB_weijie.GetItemText(CLB_weijie.Items[i]));
                }
            }
            RiderTake RT = new RiderTake(list, name);
            if (RT.Jiedan()==true)
            {
                MessageBox.Show("接单成功，请刷新界面！", "提示！！！");
            }
            else
            {
                MessageBox.Show("未知错误，请刷新界面！", "ERROR!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            list.Clear();
            for (int i = 0; i < CLB_yijie.Items.Count; i++)
            {//遍历CLB_weijie，将被勾选的选项存入list
                if (CLB_yijie.GetItemChecked(i))
                {
                    list.Add(CLB_yijie.GetItemText(CLB_yijie.Items[i]));
                }
            }
            RiderTake RT = new RiderTake(list, name);
            if (RT.WanCheng() == true)
            {
                MessageBox.Show("恭喜你已完成订单", "提示！！！");
            }
            else
            {
                MessageBox.Show("未知错误，请刷新界面！", "ERROR!");
            }
        }

        private void refresh1_Click(object sender, EventArgs e)
        {
            this.Close();
            new Take(name).Show();
        }

        private void refresh2_Click(object sender, EventArgs e)
        {
            this.Close();
            new Take(name).Show();
        }
    }
}
