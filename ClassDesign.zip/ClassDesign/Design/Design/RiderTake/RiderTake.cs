﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Design
{
    class RiderTake
    {
        private static string ConStr = "Data Source=.;Initial Catalog=CanteenManage;Integrated Security=True";
        //连接字符串
        ArrayList list = new ArrayList();//接收选中的Num的list
        string phone = string.Empty;//接收Riderphone
        public RiderTake(ArrayList ar,string num)
        {
            list = ar;
            phone = num;
        }

        public bool Jiedan()
            //接单
        {
            foreach(var a in list)
            {
                string SqlStr = "update dingdan set Status= '已接单' , Riderphone=" + phone +"where Num="+a ;
                //sql语句，通过订单编号Num更改订单状态和骑手phone
                SqlConnection conn = new SqlConnection(ConStr);
                SqlCommand cmd = new SqlCommand(SqlStr, conn);
                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();//执行数据库写入
                    return true;
                }
                finally
                {
                    conn.Close();
                }
            }
            return false;
        }

        public bool WanCheng()
            //完成订单
        {
            foreach (var a in list)
            {
                string SqlStr = "update dingdan set Status= '已完成' where Num=" + a;
                //通过订单编号Num更新订单状态
                SqlConnection conn = new SqlConnection(ConStr);
                SqlCommand cmd = new SqlCommand(SqlStr, conn);
                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();//执行数据库更新语句
                    return true;
                }
                finally
                {
                    conn.Close();
                }
            }
            return false;
        }
    }
}
