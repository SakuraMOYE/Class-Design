﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Design
{
    public partial class enrollment : Form
    {
        public enrollment()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 0;//comBox1的默认值设为第一个及 用户注册
        }

        string select="用户注册";
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            select = comboBox1.SelectedItem.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {//取消按钮，关闭注册界面
            DialogResult dr= MessageBox.Show("是否退出注册？", "提示");
            if(dr==DialogResult.OK)
            {
                this.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {//判断手机号、昵称或密码是否为空以及两次密码输入是否一致！
            if (phoneNum.Text.Trim() == "")
            {
                MessageBox.Show("手机号不能为空");
            }
            else if (passWord1.Text.Trim() == "" && passWord2.Text.Trim() == "")
            {
                MessageBox.Show("密码不能为空");
            }
            else if (la_name.Text.Trim() == "")
            {
                MessageBox.Show("昵称不能为空");
            }
            else if (passWord1.Text.Trim() != passWord2.Text.Trim())
            {
                MessageBox.Show("两次密码输入不一致，请重新输入");
            }
            else
            {
                Judge ju = new Judge(phoneNum.Text.Trim(), la_name.Text.Trim());
                Write wr = new Write(phoneNum.Text.Trim(), passWord1.Text.Trim(), la_name.Text.Trim());
                //实例化Judge、Write并将用户输入传递到构造函数
                switch (select)
                {
                    case ("用户注册"):
                        if(ju.usernameconflict ()==true)
                        {//通过手机号或者昵称查询的结果大于零
                            MessageBox.Show("该手机号已被注册或该昵称已被使用");
                        }
                        else
                        {
                            wr.userenrollWrite();//用户数据写入并关闭窗口
                            DialogResult dr= MessageBox.Show("注册成功，点击确认后前往登录界面", "提示");
                            if(dr==DialogResult.OK)
                            {
                                this.Close();
                            }
                        }
                        break;
                    case ("骑手注册"):
                        if (ju.ridernameconflict () == true)
                        {//通过手机号或者昵称查询的结果大于零
                            MessageBox.Show("该昵称已被使用");
                        }
                        else
                        {
                            wr.riderenrollWrite();//骑手数据写入并关闭窗口
                            DialogResult dr = MessageBox.Show("注册成功，点击确认后前往登录界面", "提示");
                            if (dr == DialogResult.OK)
                            {
                                this.Close();
                            }
                        }
                        break;
                }
            }
        }
    }
}
