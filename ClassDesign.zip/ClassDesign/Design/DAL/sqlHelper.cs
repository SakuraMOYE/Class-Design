﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
     public class sqlHelper
    {
        //读取配置文件，连接数据库语句
        public static string strCon = System.Configuration.ConfigurationManager.ConnectionStrings["dbConnection"].ConnectionString;
        SqlConnection con = new SqlConnection(strCon);//实例化连接对象con

        public void chkConnection()//检测连接是否打开
        {
            if (this.con.State == ConnectionState.Closed)
            {
                this.con.Open();
            }
        }
        public int returnRowCount(string strSQL)//执行语句，返回该语句查询的数据行总数
        {
            chkConnection();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter(strSQL, con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                return ds.Tables[0].Rows.Count;
            }
            catch
            {
                return 0;
            }
        }
    }
}
