﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class LoginDAO
    {
        sqlHelper s = new sqlHelper();
        public int userLogin(string name, string psw)//用户连接
        {//设置查询语句，调用可以返回语句可以查询的方法
            string strsql = "select * from userInfo where ID='" + name + "'and passWord='" + psw + "'";
            return s.returnRowCount(strsql);//调用数据库中查询语句，返回查询到的结果
        }
        public int riderLogin(string name, string psw)//骑手连接
        {
            string strsql = "select * from Rider where ID='" + name + "'and passWord='" + psw + "'";
            return s.returnRowCount(strsql);
        }
        public int manageLogin(string name, string psw)//管理连接
        {
            string strsql = "select * from Administration where ID='" + name + "'and passWord='" + psw + "'";
            return s.returnRowCount(strsql);
        }
    }
}
