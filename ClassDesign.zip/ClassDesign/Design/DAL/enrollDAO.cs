﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class enrollDAO
    {
        sqlHelper s = new sqlHelper();
        public int userenrollJudge(string phoneNum,string Name)
        {
            string strsql = "select * from userInfo where ID='" + phoneNum + "'or Name='" + Name + "'";
            //通过ID和Name查询数据库内该用户是否已经注册过
            return s.returnRowCount(strsql);
        }
        public int userenrollWrite(string phoneNum, string passWord, string Name)
        {
            string strsql = "insert userInfo (ID,passWord,Name) values ('"+phoneNum +"','"+passWord +"','"+Name+"')";
            return s.returnRowCount(strsql);
            //若数据库中查询结果不存在，将用户数据写入数据库
        }
        public int riderenrollJudge(string phoneNum, string Name)
        {
            string strsql = "select * from Rider where ID='" + phoneNum + "'or Name='" + Name + "'";
            //通过ID和Name查询数据库内骑手是否已经注册过
            return s.returnRowCount(strsql);
        }
        public int riderenrollWrite(string phoneNum, string passWord, string Name)
        {
            string strsql = "insert Rider (ID,passWord,Name) values ('" + phoneNum + "','" + passWord + "','" + Name + "')";
            return s.returnRowCount(strsql);
            //若数据库中查询结果不存在，将骑手数据写入数据库
        }
    }
}
