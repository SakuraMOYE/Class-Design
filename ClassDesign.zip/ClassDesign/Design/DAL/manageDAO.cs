﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class manageDAO
    {
        sqlHelper s = new sqlHelper();
        public int dishSearch(string ID, string name)
        {
            string strsql = "select * from Dish where ID='" + ID + "'or name='" + name + "'";
            //通过ID和name查询数据库内是否已经有这个ID或者这个菜名已被记录
            return s.returnRowCount(strsql);
        }
        public int dishAdd(string ID, string name, string price)
        {
            string strsql = "insert Dish (ID,name,price) values ('" + ID + "','" + name + "','" + price  + "')";
            return s.returnRowCount(strsql);
            //若数据库中查询结果不存在，在数据库中添加这道菜
        }
        public int dishDelete(string ID,string name)
        {
            string strsql = "delete from Dish where ID='" + ID + "'or name='" + name + "'";
            return s.returnRowCount(strsql);
            //通过查询ID或者name来删除菜
        }
        public int dishUpdate(string ID,string name, string price)
        {
            string strsql="update Dish set price='"+price+ "'where ID='" + ID + "' or name='" + name + "'";
            return s.returnRowCount(strsql);
            //通过ID或者name更改菜的价格
        }
    }
}
