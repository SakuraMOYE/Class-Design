﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class enrollManage
    {
        DAL.enrollDAO d = new DAL.enrollDAO();
        public int userEnrollJudge(Model.enrollInfo m_userInfo)//用户查询渠道
        {
            return d.userenrollJudge(m_userInfo.phoneNum , m_userInfo.Name );
        }
        public int userEnrollWrite(Model.enrollInfo m_userInfo)//用户写入渠道
        {
            return d.userenrollWrite(m_userInfo.phoneNum, m_userInfo.passWords, m_userInfo.Name);
        }
        public int riderEnrollJudge(Model.enrollInfo m_userInfo)//骑手查询渠道
        {
            return d.riderenrollJudge(m_userInfo.phoneNum , m_userInfo.Name);
        }
        public int riderEnrollWrite(Model.enrollInfo m_userInfo)//骑手写入渠道
        {
            return d.riderenrollWrite(m_userInfo.phoneNum, m_userInfo.passWords, m_userInfo.Name);
        }
    }
}
