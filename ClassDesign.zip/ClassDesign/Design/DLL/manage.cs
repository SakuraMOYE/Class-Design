﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class manage
    {
        DAL.manageDAO d = new DAL.manageDAO();
        public int dishSearch(Model .manage m_manage)
        {
            return d.dishSearch(m_manage.ID, m_manage.name);
        }
        public int dishAdd(Model.manage  m_manage)//用户数据传入渠道
        {
            return d.dishAdd(m_manage .ID,m_manage.name,m_manage.price);
        }
        public int dishDelete(Model.manage m_manage)//用户数据传入渠道
        {
            return d.dishDelete(m_manage.ID, m_manage.name);

        }
        public int dishUpdate(Model.manage m_manage)//用户数据传入渠道
        {
            return d.dishUpdate(m_manage.ID, m_manage.name, m_manage.price);
        }
    }
}
