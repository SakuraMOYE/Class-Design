﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class loginManage//登录连接管理
    {
        DAL.LoginDAO d = new DAL.LoginDAO();
        public int userLogin(Model.userInfo m_userInfo)//用户数据传入渠道
        {
            return d.userLogin(m_userInfo.UserName, m_userInfo.PassWords);
        }
        public int riderLogin(Model.userInfo m_userInfo)//骑手数据传入渠道
        {
            return d.riderLogin(m_userInfo.UserName, m_userInfo.PassWords);
        }
        public int manageLogin(Model.userInfo m_userInfo)//管理数据传入渠道
        {
            return d.manageLogin(m_userInfo.UserName, m_userInfo.PassWords);
        }
    }
}
